package Desafio_Tecnico.API_transacao;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiTransacaoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiTransacaoApplication.class, args);
	}

}
